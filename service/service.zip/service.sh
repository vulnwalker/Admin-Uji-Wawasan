while sleep 900; do php serverLog.php ; done
